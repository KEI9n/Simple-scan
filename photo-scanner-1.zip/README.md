# Photo Scanner
スマホや PC で文書のスキャンを効率化する[アプリ](https://marmooo.github.io/photo-scanner/)です。
カメラで撮影した写真を、スキャナー画像のように自動で補正します。

## Build
```
build_model.sh
build_opencvjs.sh
build_release.sh
```

