tensorflowjs_converter --quantization_bytes 1 --input_format=keras denoise.model denoise
